///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
	const bool g_MeshBaseAtOrigin = true;
	const float g_TorusMainRadius = 1.0f;
	const float g_HearthTop = 0.25f;
	const float g_MantelTop = 7.5f;
	const float g_OpeningTop = 5.6f;
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection so the first loaded
	// texture lands in slot 0 instead of a garbage index
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
*  SetLightingEnabled()
*
*  Turns the Phong lighting calculation on or off so glowing
*  objects (flames) can be drawn at full brightness.
***********************************************************/
void SceneManager::SetLightingEnabled(bool bEnabled)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setBoolValue(g_UseLightingName, bEnabled);
	}
}

/***********************************************************
 *  RenderTexturedBox()
 *
 *  Draws a box centered on the given position with a texture
 *  and material. tileSize is the world-unit size of one
 *  texture repeat so the texture is not stretched.
 ***********************************************************/
void SceneManager::RenderTexturedBox(
	glm::vec3 scaleXYZ,
	glm::vec3 centerXYZ,
	std::string textureTag,
	std::string materialTag,
	float tileSize)
{
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, centerXYZ);
	SetShaderTexture(textureTag);
	SetShaderMaterial(materialTag);
	SetTextureUVScale(scaleXYZ.x / tileSize, scaleXYZ.y / tileSize);
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderColoredBox()
 *
 *  Draws a solid-color box centered on the given position.
 ***********************************************************/
void SceneManager::RenderColoredBox(
	glm::vec3 scaleXYZ,
	glm::vec3 centerXYZ,
	glm::vec3 color,
	std::string materialTag)
{
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, centerXYZ);
	SetShaderColor(color.r, color.g, color.b, 1.0f);
	SetShaderMaterial(materialTag);
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderCylinder()
 *
 *  Draws a cylinder so that centerXYZ is the middle of its
 *  length, whatever rotation is applied. The caller sets the
 *  texture or color and material before calling.
 ***********************************************************/
void SceneManager::RenderCylinder(
	glm::vec3 centerXYZ,
	float radius,
	float length,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees)
{
	// same rotation order SetTransformations uses
	glm::mat4 rotation =
		glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f)) *
		glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f)) *
		glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));

	// shift from the middle of the length to the mesh origin
	glm::vec3 localOffset = g_MeshBaseAtOrigin ?
		glm::vec3(0.0f, -length * 0.5f, 0.0f) : glm::vec3(0.0f);
	glm::vec3 position = centerXYZ + glm::vec3(rotation * glm::vec4(localOffset, 1.0f));

	SetTransformations(
		glm::vec3(radius, length, radius),
		XrotationDegrees, YrotationDegrees, ZrotationDegrees,
		position);
	m_basicMeshes->DrawCylinderMesh();
}

/***********************************************************
 *  RenderCone()
 *
 *  Draws an upright cone with its base centered on the given
 *  position. The caller sets color/texture and material.
 ***********************************************************/
void SceneManager::RenderCone(
	glm::vec3 baseCenterXYZ,
	float radius,
	float height)
{
	glm::vec3 position = baseCenterXYZ;
	if (!g_MeshBaseAtOrigin)
	{
		position.y += height * 0.5f;
	}

	SetTransformations(
		glm::vec3(radius, height, radius),
		0.0f, 0.0f, 0.0f,
		position);
	m_basicMeshes->DrawConeMesh();
}

/***********************************************************
 *  RenderSphere()
 *
 *  Draws a sphere centered on the given
 *  position with a separate radius per axis. The caller sets
 *  color/texture and material.
 ***********************************************************/
void SceneManager::RenderSphere(
	glm::vec3 centerXYZ,
	glm::vec3 radiiXYZ,
	float ZrotationDegrees)
{
	SetTransformations(radiiXYZ, 0.0f, 0.0f, ZrotationDegrees, centerXYZ);
	m_basicMeshes->DrawSphereMesh();
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  RenderBook()
 *
 * Renders a complete book using four solid Box meshes:
 * 1. Top Cover
 * 2. Bottom Cover
 * 3. Spine Cover
 * 4. Inner Pages Block
 ***********************************************************/
void SceneManager::RenderBook(
	glm::vec3 scaleXYZ,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ,
	std::string pagesTextureTag,
	std::string coverTextureTag)
{
	float XrotationDegrees = 0.0f;

	float coverThickness = 0.04f;
	float spineThickness = 0.05f;
	float pageHeight = scaleXYZ.y - (2.0f * coverThickness);

	float insetX = 0.08f;
	float insetZ = 0.12f;

	const float leatherRepeatSize = 3.0f;

	glm::mat4 rotY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));


	// 1. TOP COVER (BOX MESH)
	glm::vec3 topCoverScale = glm::vec3(scaleXYZ.x, coverThickness, scaleXYZ.z);
	glm::vec3 topLocalOffset = glm::vec3(0.0f, (scaleXYZ.y / 2.0f) - (coverThickness / 2.0f), 0.0f);
	glm::vec3 topWorldPos = positionXYZ + glm::vec3(rotY * glm::vec4(topLocalOffset, 1.0f));

	SetTransformations(
		topCoverScale,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		topWorldPos);
	SetShaderTexture(coverTextureTag);
	SetShaderMaterial("leather");
	SetTextureUVScale(scaleXYZ.x / leatherRepeatSize, scaleXYZ.z / leatherRepeatSize);
	m_basicMeshes->DrawBoxMesh();

	// 2. BOTTOM COVER (BOX MESH)
	glm::vec3 bottomCoverScale = glm::vec3(scaleXYZ.x, coverThickness, scaleXYZ.z);
	glm::vec3 bottomLocalOffset = glm::vec3(0.0f, -(scaleXYZ.y / 2.0f) + (coverThickness / 2.0f), 0.0f);
	glm::vec3 bottomWorldPos = positionXYZ + glm::vec3(rotY * glm::vec4(bottomLocalOffset, 1.0f));

	SetTransformations(
		bottomCoverScale,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		bottomWorldPos);
	SetShaderTexture(coverTextureTag);
	SetShaderMaterial("leather");
	SetTextureUVScale(scaleXYZ.x / leatherRepeatSize, scaleXYZ.z / leatherRepeatSize);
	m_basicMeshes->DrawBoxMesh();

	//  SPINE COVER (BOX MESH)
	glm::vec3 spineScale = glm::vec3(scaleXYZ.x, pageHeight, spineThickness);
	glm::vec3 spineLocalOffset = glm::vec3(0.0f, 0.0f, (scaleXYZ.z / 2.0f) - (spineThickness / 2.0f));
	glm::vec3 spineWorldPos = positionXYZ + glm::vec3(rotY * glm::vec4(spineLocalOffset, 1.0f));

	SetTransformations(
		spineScale, XrotationDegrees, YrotationDegrees, ZrotationDegrees, spineWorldPos);
	SetShaderTexture(coverTextureTag);
	SetShaderMaterial("leather");
	SetTextureUVScale(scaleXYZ.x / leatherRepeatSize, pageHeight / leatherRepeatSize);
	m_basicMeshes->DrawBoxMesh();

	//  INNER PAGES BLOCK
	glm::vec3 pagesScale = glm::vec3(scaleXYZ.x - insetX, pageHeight, scaleXYZ.z - insetZ);
	glm::vec3 pagesLocalOffset = glm::vec3(0.0f, 0.0f, -insetZ / 2.0f);
	glm::vec3 pagesWorldPos = positionXYZ + glm::vec3(rotY * glm::vec4(pagesLocalOffset, 1.0f));

	SetTransformations(
		pagesScale,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		pagesWorldPos);
	SetShaderTexture(pagesTextureTag);
	SetShaderMaterial("paper");
	SetTextureUVScale(1.0f, 0.2f);
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderBookStack()
 *
 *  Draws four books stacked with slightly different sizes and
 *  angles so the pile looks hand-placed. stackBasePos is the
 *  point on the surface the bottom book rests on.
 ***********************************************************/
void SceneManager::RenderBookStack(glm::vec3 stackBasePos)
{
	// leather texture used for each book cover
	const std::string yellowLeather = "leather031";
	const std::string redLeather = "leather033B";
	const std::string greyLeather = "leather037";
	const std::string blackLeather = "leather038";

	float baseAngle = 0.0f;

	// Book 1 (bottom, largest)
	RenderBook(
		glm::vec3(3.2f, 0.6f, 2.2f),
		baseAngle,
		0.0f,
		stackBasePos + glm::vec3(0.0f, 0.30f, 0.0f),
		"pages",
		yellowLeather);

	// Book 2
	RenderBook(
		glm::vec3(2.9f, 0.45f, 2.0f),
		baseAngle + 3.0f,
		0.0f,
		stackBasePos + glm::vec3(0.05f, 0.825f, -0.02f),
		"pages",
		redLeather);

	// Book 3
	RenderBook(
		glm::vec3(2.6f, 0.40f, 1.8f),
		baseAngle - 2.0f,
		0.0f,
		stackBasePos + glm::vec3(0.02f, 1.25f, 0.01f),
		"pages",
		greyLeather);

	// Book 4 (top, turned sideways)
	RenderBook(
		glm::vec3(2.3f, 0.50f, 1.6f),
		baseAngle - 90.0f,
		0.0f,
		stackBasePos + glm::vec3(-0.02f, 1.70f, 0.03f),
		"pages",
		blackLeather);
}

/***********************************************************
 *  RenderCandle()
 *
 *  Draws a candle from two cylinders-worth of shapes: a wax
 *  cylinder and a glowing two-sphere flame. If bOnHolder is
 *  true the candle sits on a dark metal holder (cylinders).
 *  baseXYZ is the point on the surface it rests on.
 ***********************************************************/
void SceneManager::RenderCandle(
	glm::vec3 baseXYZ,
	float height,
	float radius,
	bool bOnHolder)
{
	float holderHeight = 0.0f;

	if (bOnHolder)
	{
		holderHeight = 0.9f;

		SetShaderColor(0.07f, 0.06f, 0.06f, 1.0f);
		SetShaderMaterial("metal");
		// round foot, thin stem, and small cup under the candle
		RenderCylinder(baseXYZ + glm::vec3(0.0f, 0.05f, 0.0f),
			radius * 1.9f, 0.10f, 0.0f, 0.0f, 0.0f);
		RenderCylinder(baseXYZ + glm::vec3(0.0f, holderHeight * 0.5f, 0.0f),
			radius * 0.35f, holderHeight, 0.0f, 0.0f, 0.0f);
		RenderCylinder(baseXYZ + glm::vec3(0.0f, holderHeight, 0.0f),
			radius * 1.3f, 0.12f, 0.0f, 0.0f, 0.0f);
		holderHeight += 0.06f;
	}

	// wax body
	SetShaderColor(0.96f, 0.90f, 0.74f, 1.0f);
	SetShaderMaterial("wax");
	RenderCylinder(baseXYZ + glm::vec3(0.0f, holderHeight + height * 0.5f, 0.0f),
		radius, height, 0.0f, 0.0f, 0.0f);

	// flame is drawn unlit so it glows at full brightness
	glm::vec3 candleTop = baseXYZ + glm::vec3(0.0f, holderHeight + height, 0.0f);
	SetLightingEnabled(false);
	SetShaderColor(1.0f, 0.60f, 0.15f, 1.0f);
	RenderSphere(candleTop + glm::vec3(0.0f, 0.28f, 0.0f),
		glm::vec3(0.13f, 0.30f, 0.13f), 0.0f);
	SetShaderColor(1.0f, 0.93f, 0.55f, 1.0f);
	RenderSphere(candleTop + glm::vec3(0.0f, 0.22f, 0.0f),
		glm::vec3(0.07f, 0.18f, 0.07f), 0.0f);
	SetLightingEnabled(true);
}

/***********************************************************
 *  RenderPumpkin()
 *
 *  Draws a pumpkin from a squashed sphere and a short
 *  cylinder stem. baseXYZ is the point on the surface the
 *  pumpkin rests on; color is the skin color.
 ***********************************************************/
void SceneManager::RenderPumpkin(
	glm::vec3 baseXYZ,
	float radius,
	glm::vec3 color)
{
	float bodyHalfHeight = radius * 0.82f;

	// squashed body
	SetShaderColor(color.r, color.g, color.b, 1.0f);
	SetShaderMaterial("pumpkin");
	RenderSphere(baseXYZ + glm::vec3(0.0f, bodyHalfHeight, 0.0f),
		glm::vec3(radius, bodyHalfHeight, radius), 0.0f);

	// stem, tilted slightly
	SetShaderColor(0.36f, 0.27f, 0.13f, 1.0f);
	SetShaderMaterial("matte");
	RenderCylinder(
		baseXYZ + glm::vec3(0.0f, bodyHalfHeight * 2.0f + radius * 0.10f, 0.0f),
		radius * 0.14f, radius * 0.40f,
		0.0f, 0.0f, 12.0f);
}

/***********************************************************
 *  RenderPineCone()
 *
 *  Draws a pine cone from a bark-textured sphere body and a
 *  small cone tip. baseXYZ is the point it rests on.
 ***********************************************************/
void SceneManager::RenderPineCone(glm::vec3 baseXYZ)
{
	SetShaderTexture("bark");
	SetShaderMaterial("bark");
	SetTextureUVScale(1.0f, 1.0f);

	// narrow body
	RenderSphere(baseXYZ + glm::vec3(0.0f, 0.55f, 0.0f),
		glm::vec3(0.38f, 0.55f, 0.38f), 0.0f);

	// four tiers of small flattened spheres form the scales; the tiers
	// are widest in the middle so the cone tapers at both ends
	const int tierCount = 4;
	const int scalesPerTier = 8;
	const float tierHeight[tierCount] = { 0.20f, 0.45f, 0.70f, 0.92f };
	const float tierRadius[tierCount] = { 0.34f, 0.43f, 0.40f, 0.28f };
	const float scaleSize[tierCount] = { 0.15f, 0.17f, 0.15f, 0.11f };

	for (int tier = 0; tier < tierCount; tier++)
	{
		for (int i = 0; i < scalesPerTier; i++)
		{
			// every other tier is turned half a step so the scales overlap
			float angle = glm::radians(360.0f * (i + 0.5f * (tier % 2)) / scalesPerTier);
			glm::vec3 scalePos = baseXYZ + glm::vec3(
				cosf(angle) * tierRadius[tier],
				tierHeight[tier],
				sinf(angle) * tierRadius[tier]);
			RenderSphere(scalePos,
				glm::vec3(scaleSize[tier], scaleSize[tier] * 0.6f, scaleSize[tier]),
				0.0f);
		}
	}
}

/***********************************************************
 *  RenderWreath()
 *
 *  Draws a fall wreath: a torus ring covered with flattened
 *  sphere leaves in orange, red and gold. The ring faces the
 *  camera (+Z).
 ***********************************************************/
void SceneManager::RenderWreath(
	glm::vec3 centerXYZ,
	float radius)
{
	// ring of twigs
	SetShaderColor(0.32f, 0.22f, 0.12f, 1.0f);
	SetShaderMaterial("leaf");
	SetTransformations(
		glm::vec3(radius, radius, radius),
		0.0f, 0.0f, 0.0f,
		centerXYZ);
	m_basicMeshes->DrawTorusMesh();

	// leaves placed evenly around the ring, alternating colors
	const int leafCount = 36;
	const glm::vec3 leafColors[3] = {
		glm::vec3(0.78f, 0.33f, 0.08f),   // burnt orange
		glm::vec3(0.62f, 0.14f, 0.07f),   // red
		glm::vec3(0.80f, 0.58f, 0.12f)    // gold
	};

	SetShaderMaterial("leaf");
	for (int i = 0; i < leafCount; i++)
	{
		float angle = glm::radians(360.0f * i / leafCount);
		float ringRadius = radius * g_TorusMainRadius * ((i % 2) ? 1.06f : 0.94f);
		glm::vec3 leafPos = centerXYZ + glm::vec3(
			cosf(angle) * ringRadius,
			sinf(angle) * ringRadius,
			0.55f);
		glm::vec3 color = leafColors[i % 3];

		SetShaderColor(color.r, color.g, color.b, 1.0f);
		RenderSphere(leafPos, glm::vec3(0.55f, 0.22f, 0.20f),
			glm::degrees(angle) + 90.0f);
	}
}

/***********************************************************
 *  RenderPilaster()
 *
 *  Draws one fluted fireplace column from boxes (shaft, base,
 *  capital, flutes) and a flattened-sphere medallion.
 *  centerX is the column's center on the X axis.
 ***********************************************************/
void SceneManager::RenderPilaster(float centerX)
{
	// shaft, base block and capital block
	RenderTexturedBox(glm::vec3(1.8f, 7.0f, 1.2f), glm::vec3(centerX, 3.5f, -4.1f),
		"whitestone", "stone", 4.0f);
	RenderTexturedBox(glm::vec3(2.0f, 0.5f, 1.4f), glm::vec3(centerX, 0.5f, -4.0f),
		"whitestone", "stone", 4.0f);
	RenderTexturedBox(glm::vec3(2.0f, 0.35f, 1.4f), glm::vec3(centerX, 6.725f, -4.0f),
		"whitestone", "stone", 4.0f);

	// three thin grey flutes down the front face
	for (int i = -1; i <= 1; i++)
	{
		RenderColoredBox(glm::vec3(0.08f, 4.8f, 0.04f),
			glm::vec3(centerX + i * 0.45f, 3.4f, -3.49f),
			glm::vec3(0.62f, 0.60f, 0.56f), "matte");
	}

	// round medallion near the top of the shaft
	SetShaderTexture("whitestone");
	SetShaderMaterial("stone");
	SetTextureUVScale(1.0f, 1.0f);
	RenderSphere(glm::vec3(centerX, 6.0f, -3.5f), glm::vec3(0.42f, 0.42f, 0.10f), 0.0f);
}

/***********************************************************
 *  RenderFirebox()
 *
 *  Draws the opening of the fireplace: brick back and side
 *  walls, a sooty ceiling, crossed bark-covered logs (rotated
 *  cylinders), glowing embers, and cone flames.
 ***********************************************************/
void SceneManager::RenderFirebox()
{
	// brick back wall and two brick side walls
	RenderTexturedBox(glm::vec3(8.0f, 5.35f, 0.2f), glm::vec3(0.0f, 2.925f, -4.6f),
		"pavers", "brick", 1.6f);
	RenderTexturedBox(glm::vec3(0.2f, 5.35f, 1.2f), glm::vec3(-3.9f, 2.925f, -4.1f),
		"pavers", "brick", 2.5f);
	RenderTexturedBox(glm::vec3(0.2f, 5.35f, 1.2f), glm::vec3(3.9f, 2.925f, -4.1f),
		"pavers", "brick", 2.5f);

	// soot-darkened ceiling of the firebox
	RenderColoredBox(glm::vec3(7.6f, 0.1f, 1.2f), glm::vec3(0.0f, 5.55f, -4.1f),
		glm::vec3(0.12f, 0.10f, 0.09f), "matte");

	// logs: cylinders turned on their sides and yawed so they cross
	SetShaderTexture("bark");
	SetShaderMaterial("bark");
	SetTextureUVScale(2.0f, 1.0f);
	RenderCylinder(glm::vec3(-0.2f, 0.65f, -4.05f), 0.38f, 3.2f, 0.0f, 12.0f, 90.0f);
	RenderCylinder(glm::vec3(0.4f, 0.60f, -3.9f), 0.34f, 3.0f, 0.0f, -28.0f, 90.0f);
	RenderCylinder(glm::vec3(-0.1f, 1.20f, -3.95f), 0.30f, 2.6f, 0.0f, 20.0f, 90.0f);

	// flames and embers are unlit so they glow
	SetLightingEnabled(false);
	SetShaderColor(0.95f, 0.30f, 0.8f, 1.0f);
	RenderColoredBox(glm::vec3(3.0f, 0.08f, 1.0f), glm::vec3(0.0f, g_HearthTop + 0.05f, -3.95f),
		glm::vec3(0.95f, 0.30f, 0.05f), "matte");

	SetShaderColor(1.0f, 0.50f, 0.08f, 1.0f);
	SetShaderColor(0.90f, 0.20f, 0.03f, 1.0f);       
	RenderCone(glm::vec3(0.0f, 1.0f, -3.95f), 0.75f, 2.8f);
	RenderCone(glm::vec3(-0.9f, 0.95f, -3.9f), 0.40f, 1.5f);
	RenderCone(glm::vec3(0.95f, 0.95f, -3.9f), 0.42f, 1.7f);

	SetShaderColor(1.0f, 0.50f, 0.08f, 1.0f);     
	RenderCone(glm::vec3(0.0f, 1.0f, -3.70f), 0.55f, 2.2f);

	SetShaderColor(1.0f, 0.88f, 0.35f, 1.0f);
	RenderCone(glm::vec3(0.0f, 1.0f, -3.45f), 0.36f, 1.5f);
	SetLightingEnabled(true);
}

/***********************************************************
 *  RenderFireplace()
 *
 *  Draws the wall, the stone hearth, both pilasters, the
 *  frieze with its medallion, the mantel shelf, and the
 *  firebox. Everything is positioned from the shared
 *  constants so the pieces line up.
 ***********************************************************/
void SceneManager::RenderFireplace()
{
	// back wall behind the fireplace
	RenderColoredBox(glm::vec3(44.0f, 15.0f, 0.4f), glm::vec3(0.0f, 7.5f, -4.9f),
		glm::vec3(0.82f, 0.78f, 0.72f), "wall");

	// stone hearth the fire and the decorations sit on
	RenderTexturedBox(glm::vec3(16.0f, g_HearthTop, 4.2f), glm::vec3(0.0f, g_HearthTop * 0.5f, -2.6f),
		"travertine009", "stone", 4.0f);

	// columns on both sides of the opening
	RenderPilaster(-4.9f);
	RenderPilaster(4.9f);

	RenderTexturedBox(glm::vec3(8.02f, 7.0f - g_OpeningTop, 1.2f),
		glm::vec3(0.0f, (7.0f + g_OpeningTop) * 0.5f, -4.1f),
		"whitestone", "stone", 4.0f);
	SetShaderTexture("whitestone");
	SetShaderMaterial("stone");
	SetTextureUVScale(1.0f, 1.0f);
	RenderSphere(glm::vec3(0.0f, 6.3f, -3.5f), glm::vec3(0.55f, 0.55f, 0.12f), 0.0f);

	// mantel shelf
	RenderTexturedBox(glm::vec3(13.0f, g_MantelTop - 7.0f, 2.0f),
		glm::vec3(0.0f, (7.0f + g_MantelTop) * 0.5f, -3.7f),
		"whitestone", "stone", 4.0f);

	RenderFirebox();
}

/***********************************************************
 *  RenderMantelDecor()
 *
 *  Places the candles, small pumpkins, foliage and wreath
 *  that decorate the mantel, reusing the object functions.
 ***********************************************************/
void SceneManager::RenderMantelDecor()
{
	const float z = -3.9f;

	// three candles on each side, some on holders
	RenderCandle(glm::vec3(-4.6f, g_MantelTop, z), 1.6f, 0.32f, false);
	RenderCandle(glm::vec3(-3.7f, g_MantelTop, z), 1.5f, 0.24f, true);
	RenderCandle(glm::vec3(-2.6f, g_MantelTop, z), 1.2f, 0.34f, false);
	RenderCandle(glm::vec3(2.6f, g_MantelTop, z), 1.8f, 0.30f, false);
	RenderCandle(glm::vec3(3.6f, g_MantelTop, z), 1.4f, 0.22f, true);
	RenderCandle(glm::vec3(4.6f, g_MantelTop, z), 1.5f, 0.34f, false);

	// small cream pumpkins at each end of the mantel
	RenderPumpkin(glm::vec3(-5.8f, g_MantelTop, -3.7f), 0.55f, glm::vec3(0.93f, 0.84f, 0.62f));
	RenderPumpkin(glm::vec3(5.8f, g_MantelTop, -3.7f), 0.55f, glm::vec3(0.88f, 0.52f, 0.14f));

	// autumn leaves tucked between the candles and the center
	SetShaderMaterial("leaf");
	const glm::vec3 foliage[6] = {
		glm::vec3(-1.5f, g_MantelTop + 0.2f, -3.4f),
		glm::vec3(-1.0f, g_MantelTop + 0.3f, -3.6f),
		glm::vec3(-0.5f, g_MantelTop + 0.2f, -3.3f),
		glm::vec3(0.5f, g_MantelTop + 0.2f, -3.3f),
		glm::vec3(1.0f, g_MantelTop + 0.3f, -3.6f),
		glm::vec3(1.5f, g_MantelTop + 0.2f, -3.4f)
	};
	for (int i = 0; i < 6; i++)
	{
		if (i % 2 == 0)
			SetShaderColor(0.72f, 0.28f, 0.07f, 1.0f);
		else
			SetShaderColor(0.55f, 0.12f, 0.06f, 1.0f);
		RenderSphere(foliage[i], glm::vec3(0.32f, 0.20f, 0.25f), (i - 2.5f) * 12.0f);
	}

	// wreath hangs on the wall above the center of the mantel
	RenderWreath(glm::vec3(0.0f, 10.8f, -4.45f), 2.4f);
}

/***********************************************************
 *  RenderHearthDecor()
 *
 *  Places the book stack, pine cone and pumpkins on the hearth.
 ***********************************************************/
void SceneManager::RenderHearthDecor()
{
	// books on the left side of the hearth, pine cone on top
	glm::vec3 stackBase = glm::vec3(-5.9f, g_HearthTop, -1.9f);
	RenderBookStack(stackBase);
	RenderPineCone(stackBase + glm::vec3(0.0f, 1.95f, 0.0f));

	// small pumpkin in front of the books
	RenderPumpkin(glm::vec3(-3.5f, g_HearthTop, -1.1f), 0.45f, glm::vec3(0.88f, 0.45f, 0.12f));

	// three pumpkins on the right side: cream, large orange, small orange
	RenderPumpkin(glm::vec3(4.7f, g_HearthTop, -2.3f), 0.95f, glm::vec3(0.93f, 0.86f, 0.66f));
	RenderPumpkin(glm::vec3(6.6f, g_HearthTop, -1.4f), 1.05f, glm::vec3(0.90f, 0.40f, 0.08f));
	RenderPumpkin(glm::vec3(7.2f, g_HearthTop, -3.2f), 0.70f, glm::vec3(0.92f, 0.52f, 0.12f));
}

/***********************************************************
 *  RenderFloor()
 *
 *  Draws the tiled floor in front of the hearth.
 ***********************************************************/
void SceneManager::RenderFloor()
{
	SetTransformations(
		glm::vec3(20.0f, 1.0f, 10.0f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 0.0f, 0.0f));
	SetShaderTexture("tiles141");
	SetShaderMaterial("floor");
	SetTextureUVScale(8.0f, 4.0f);
	m_basicMeshes->DrawPlaneMesh();
}


/***********************************************************
 *  LoadSceneTextures()
 *
 *  Loads every texture image used by the scene into memory
 *  and binds them to texture slots. Each texture gets a tag
 *  so shapes can request it by name when they are drawn.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	// page edges, used on the box that forms each book's body
	CreateGLTexture("textures/pages_texture.jpg", "pages");

	// leather textures, used for book covers and spines
	CreateGLTexture("textures/Leather031.png", "leather031");
	CreateGLTexture("textures/Leather033B.png", "leather033B");
	CreateGLTexture("textures/Leather037.png", "leather037");
	CreateGLTexture("textures/Leather038.png", "leather038");

	// floor textures
	CreateGLTexture("textures/Tiles141.png", "tiles141");
	CreateGLTexture("textures/Travertine009.png", "travertine009");

	// fireplace textures
	CreateGLTexture("textures/Pavers.jpg", "pavers");
	CreateGLTexture("textures/Bark.jpg", "bark");
	CreateGLTexture("textures/WhiteStone.jpg", "whitestone");


	// bind all loaded textures to their slots (16 available)
	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Defines the materials used by the scene: a glossy tile
 *  floor, low-shine leather for covers, and matte paper.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	auto addMaterial = [this](std::string tag, glm::vec3 diffuse, glm::vec3 specular, float shininess)
		{
			OBJECT_MATERIAL material;
			material.diffuseColor = diffuse;
			material.specularColor = specular;
			material.shininess = shininess;
			material.tag = tag;
			m_objectMaterials.push_back(material);
		};

	// floor: tiles reflect the fire light with a visible highlight
	addMaterial("floor", glm::vec3(0.75f), glm::vec3(0.5f), 32.0f);
	// leather: weak, wide highlight so covers look worn instead of glossy
	addMaterial("leather", glm::vec3(1.0f), glm::vec3(0.1f), 8.0f);
	// paper: no specular highlight at all
	addMaterial("paper", glm::vec3(1.0f), glm::vec3(0.0f), 1.0f);
	// painted stone: soft sheen
	addMaterial("stone", glm::vec3(0.95f), glm::vec3(0.15f), 16.0f);
	// brick: red-tinted diffuse recolors the grey paver texture
	addMaterial("brick", glm::vec3(0.80f, 0.34f, 0.24f), glm::vec3(0.05f), 4.0f);
	// bark: rough, almost no highlight
	addMaterial("bark", glm::vec3(0.60f, 0.50f, 0.42f), glm::vec3(0.05f), 4.0f);
	// wax: smooth with a broad highlight
	addMaterial("wax", glm::vec3(0.95f), glm::vec3(0.4f), 24.0f);
	// pumpkin skin: waxy sheen
	addMaterial("pumpkin", glm::vec3(1.0f), glm::vec3(0.35f), 24.0f);
	// dark metal candle holders: tight bright highlight
	addMaterial("metal", glm::vec3(0.6f), glm::vec3(0.8f), 48.0f);
	// dry leaves: matte
	addMaterial("leaf", glm::vec3(1.0f), glm::vec3(0.05f), 4.0f);
	// painted wall and other matte surfaces
	addMaterial("wall", glm::vec3(0.9f), glm::vec3(0.0f), 1.0f);
	addMaterial("matte", glm::vec3(0.9f), glm::vec3(0.0f), 1.0f);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Configures three point lights: a warm fire light and a dim
 *  cool fill light so no surface is left in complete shadow.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// turn on custom lighting in the shader (the scene is black without it)
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// point light 0: warm orange fire light between the logs and the room
	m_pShaderManager->setVec3Value("pointLights[0].position", 0.0f, 2.2f, -2.0f);
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.10f, 0.08f, 0.07f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 1.0f, 0.55f, 0.20f);
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.8f, 0.5f, 0.25f);
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	// point light 1: dim cool blue-grey fill light from the front right
	m_pShaderManager->setVec3Value("pointLights[1].position", 6.0f, 7.0f, 8.0f);
	m_pShaderManager->setVec3Value("pointLights[1].ambient", 0.06f, 0.07f, 0.10f);
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", 0.30f, 0.35f, 0.50f);
	m_pShaderManager->setVec3Value("pointLights[1].specular", 0.15f, 0.15f, 0.25f);
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

	// point light 2: warm gold candle light over the mantel, in front of the wall
	m_pShaderManager->setVec3Value("pointLights[2].position", 0.0f, 9.0f, -1.5f);
	m_pShaderManager->setVec3Value("pointLights[2].ambient", 0.06f, 0.05f, 0.03f);
	m_pShaderManager->setVec3Value("pointLights[2].diffuse", 0.70f, 0.50f, 0.25f);
	m_pShaderManager->setVec3Value("pointLights[2].specular", 0.35f, 0.28f, 0.15f);
	m_pShaderManager->setBoolValue("pointLights[2].bActive", true);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	DefineObjectMaterials();
	SetupSceneLights();

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTorusMesh();
	LoadSceneTextures();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	RenderFloor();
	RenderFireplace();
	RenderMantelDecor();
	RenderHearthDecor();
}