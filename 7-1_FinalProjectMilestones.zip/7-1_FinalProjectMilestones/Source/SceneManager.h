///////////////////////////////////////////////////////////////////////////////
// scenemanager.h
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <vector>

/***********************************************************
 *  SceneManager
 *
 *  This class contains the code for preparing and rendering
 *  3D scenes, including the shader settings.
 ***********************************************************/
class SceneManager
{
public:
	// constructor
	SceneManager(ShaderManager *pShaderManager);
	// destructor
	~SceneManager();
	// pre-define the object materials for lighting
	void DefineObjectMaterials();
	// add and configure the light sources for the scene
	void SetupSceneLights();

	struct TEXTURE_INFO
	{
		std::string tag;
		uint32_t ID;
	};

	struct OBJECT_MATERIAL
	{
		glm::vec3 diffuseColor;
		glm::vec3 specularColor;
		float shininess;
		std::string tag;
	};

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;
	// pointer to basic shapes object
	ShapeMeshes* m_basicMeshes;
	// total number of loaded textures
	int m_loadedTextures;
	// loaded textures info
	TEXTURE_INFO m_textureIDs[16];
	// defined object materials
	std::vector<OBJECT_MATERIAL> m_objectMaterials;

	// load texture images and convert to OpenGL texture data
	bool CreateGLTexture(const char* filename, std::string tag);
	// bind loaded OpenGL textures to slots in memory
	void BindGLTextures();
	// free the loaded OpenGL textures
	void DestroyGLTextures();
	// find a loaded texture by tag
	int FindTextureID(std::string tag);
	int FindTextureSlot(std::string tag);
	// find a defined material by tag
	bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

	// set the transformation values 
	// into the transform buffer
	void SetTransformations(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ);

	// set the color values into the shader
	void SetShaderColor(
		float redColorValue,
		float greenColorValue,
		float blueColorValue,
		float alphaValue);

	// set the texture data into the shader
	void SetShaderTexture(
		std::string textureTag);

	// set the UV scale for the texture mapping
	void SetTextureUVScale(
		float u, float v);

	// set the object material into the shader
	void SetShaderMaterial(
		std::string materialTag);

	// turn the Phong lighting calculation on or off (used for glowing flames)
	void SetLightingEnabled(bool bEnabled);

	//  reusable drawing helpers built on the basic meshes 
	// textured box placed by its center
	void RenderTexturedBox(
		glm::vec3 scaleXYZ,
		glm::vec3 centerXYZ,
		std::string textureTag,
		std::string materialTag,
		float tileSize);
	// solid-color box placed by its center
	void RenderColoredBox(
		glm::vec3 scaleXYZ,
		glm::vec3 centerXYZ,
		glm::vec3 color,
		std::string materialTag);
	// cylinder placed by the center of its length
	void RenderCylinder(
		glm::vec3 centerXYZ,
		float radius,
		float length,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees);
	// cone placed by the center of its base
	void RenderCone(
		glm::vec3 baseCenterXYZ,
		float radius,
		float height);
	// sphere / ellipsoid placed by its center
	void RenderSphere(
		glm::vec3 centerXYZ,
		glm::vec3 radiiXYZ,
		float ZrotationDegrees);

public:

	// The following methods are for the students to 
	// customize for their own 3D scene
	void PrepareScene();
	void RenderScene();

	// loads the texture images used by the scene
	void LoadSceneTextures();

	//renders a single book
	void RenderBook(
		glm::vec3 scaleXYZ,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ,
		std::string pagesTextureTag,
		std::string coverTextureTag);

	// stack of four books resting on the given base position
	void RenderBookStack(glm::vec3 stackBasePos);
	// candle (cylinder body + glowing flame), optional metal holder
	void RenderCandle(
		glm::vec3 baseXYZ,
		float height,
		float radius,
		bool bOnHolder);
	// pumpkin (squashed sphere + cylinder stem)
	void RenderPumpkin(
		glm::vec3 baseXYZ,
		float radius,
		glm::vec3 color);
	// pine cone (textured sphere + cone tip)
	void RenderPineCone(glm::vec3 baseXYZ);
	// autumn wreath (torus ring + sphere leaves)
	void RenderWreath(
		glm::vec3 centerXYZ,
		float radius);
	// fluted fireplace column with base, capital and medallion
	void RenderPilaster(float centerX);
	// brick firebox, hearth, logs and flames
	void RenderFirebox();
	// whole fireplace: wall, surround, mantel and firebox
	void RenderFireplace();
	// candles, pumpkins and wreath on top of the mantel
	void RenderMantelDecor();
	// books, pumpkins and pine cone on the hearth
	void RenderHearthDecor();
	// tiled floor plane
	void RenderFloor();
};